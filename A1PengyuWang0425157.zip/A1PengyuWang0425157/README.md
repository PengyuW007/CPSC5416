# CPSC5416_A1

For A1, I have difficulties on Q3 and Q4. Q3, 
I have difficulties on the way to implement specified histogram after algorithm.
Q4, I don't know why, the histograms of self-designed function and built-in functions are different. 
However, the images are same. I tried my best to debug. 

Note: All my work, I implemented by MATLAB, and I pushed them to my private 
repository on [Github](https://github.com/PengyuW007/CPSC5416), and [A1](https://github.com/PengyuW007/CPSC5416/tree/master/A1) under this repository to do version control. 
If there is any issue of assignment, I can give marker access to check.